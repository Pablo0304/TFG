const { SubscribeCommand, SNSClient, ListSubscriptionsByTopicCommand, ListTopicsCommand } = require("@aws-sdk/client-sns");
const { DynamoDBClient, GetItemCommand, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

let eventTopics, email, region, snsClient, command, suscribedTopics, responseSNS, tableName, dynamoDBClient, dynamoDBObject;

exports.handler = async (event) => {
    console.log(event);

    if (event == false) {
        return "Error: Execution failed due to invalid parameters";
    }

    setVariables(event);

    try {

        if (checkPaymentSubscription() && await checkIfIsInDynamoDB()) {
            return await subscribe(dynamoDBObject.Item.Topics.S);
        }

        return {
            statusCode: 404,
            body: JSON.stringify({
                message: "Subscription failed",
                SubscriptionArnsSuceeded: suscribedTopics
            })
        };

    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Subscription failed",
                errorMessage: error.message,
                SubscriptionArnsSuceeded: suscribedTopics
            })
        };
    }
};

function setVariables(event) {
    eventTopics = convertTopicsToString(event["topics"]);
    email = event["email"];
    region = process.env.AWS_REGION;
    snsClient = new SNSClient({ region });
    suscribedTopics = "";
    tableName = process.env.DYNAMODB_TABLE_NAME;
    dynamoDBClient = new DynamoDBClient({ region });
}

function convertTopicsToString(eventTopics) {

    let aux = "";

    for (let topic of eventTopics) {
        if (eventTopics.length == 1) {
            aux += topic;
        } else {
            aux += topic + ",";
        }
    }

    if (eventTopics.length != 1) {
        aux = aux.slice(0, -1);
    }
    return aux;

}

async function checkPaymentSubscription() {
    return true;
}

async function checkIfIsInDynamoDB() {
    try {
        command = new GetItemCommand({
            TableName: tableName,
            Key: {
                "Email": { S: email }
            }
        });
        dynamoDBObject = await dynamoDBClient.send(command);
        let statusValue = dynamoDBObject.Item.Status ? Number(dynamoDBObject.Item.Status.N) : null;

        if (statusValue !== null) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: `Error al recuperar los ítems con Email "${email}" de DynamoDB` }),
        };
    }
}

async function subscribe(dynamoTopics) {
    try {
        let topicArn, nextToken;
        let allTopics = [];

        do {
            command = new ListTopicsCommand({ NextToken: nextToken });
            let res = await snsClient.send(command);

            for (let aux of res.Topics) {
                if (aux.TopicArn.includes("tfg-")) {
                    allTopics = allTopics.concat(aux.TopicArn);
                }
            }
            nextToken = res.NextToken;
        } while (nextToken);

        dynamoTopics = JSON.stringify(dynamoTopics).slice(1, -1);

        let res = await updateDynamoTopics(dynamoTopics, eventTopics);
        //   Searching for the only topic that the user wants to subscribe
        for (let topic of res) {
            topicArn = allTopics.find(element => element.includes(topic));
            if (topicArn) {
                command = new ListSubscriptionsByTopicCommand({
                    TopicArn: topicArn
                });

                let response = await snsClient.send(command);
                let matchingSubscriptions = response.Subscriptions.filter(subscription => subscription.Endpoint === email);

                if (matchingSubscriptions.length == 0) {   // If is new on the topic
                    command = new SubscribeCommand({
                        Protocol: "email",
                        TopicArn: topicArn,
                        Endpoint: email
                    });
                    responseSNS = await snsClient.send(command);
                    console.log("Suscrito a " + topicArn);
                    suscribedTopics += "," + responseSNS.TopicArn;
                } else {   // For an user who has deleted or not confirmed the subscription
                    matchingSubscriptions.forEach(async subscription => {
                        if (!subscription.SubscriptionArn.startsWith("arn:")) {
                            command = new SubscribeCommand({
                                Protocol: "email",
                                TopicArn: topicArn,
                                Endpoint: email
                            });
                            responseSNS = await snsClient.send(command);
                            console.log("Suscrito a " + topicArn);
                            suscribedTopics += "," + responseSNS.TopicArn;
                        }
                    });
                }
            }
        }

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Subscription successful",
                SubscriptionArns: suscribedTopics.slice(1, 0)
            })
        };

    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Subscription failed",
                errorMessage: error.message,
                SubscriptionArnsSuceeded: suscribedTopics
            })
        };
    }
}

async function updateDynamoTopics(dynamoTopics, eventTopics) {
    if (dynamoTopics !== eventTopics) {
        eventTopics = eventTopics.includes(',') ? eventTopics.split(',') : [eventTopics];
        dynamoTopics = dynamoTopics.includes(',') ? dynamoTopics.split(',') : [dynamoTopics];

        let res = [...new Set([...dynamoTopics, ...eventTopics])];   // Put together both arrays

        command = new UpdateItemCommand({
            TableName: tableName,
            Key: {
                "Email": { S: email }
            },
            UpdateExpression: "set #topics = :t",
            ExpressionAttributeNames: {
                "#topics": "Topics"
            },
            ExpressionAttributeValues: {
                ":t": { S: res.join(',') }
            },
            ReturnValues: "UPDATED_NEW"
        });

        await dynamoDBClient.send(command);

        return res;

    } else {
        eventTopics = eventTopics.includes(',') ? eventTopics.split(',') : [eventTopics];
        return eventTopics;

    }
}