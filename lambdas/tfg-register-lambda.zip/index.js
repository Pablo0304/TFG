const { DynamoDBClient, PutItemCommand, GetItemCommand, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

let eventTopics, date, email, regions, tableName, dynamoDBClient, command;

exports.handler = async (event) => {

    let validParameters = setVariables(event);
    if (validParameters == "") {
        return false;
    }

    if (checkPaymentSubscription() && !(await checkIfIsInDynamoDB())) {

        command = {
            TableName: tableName,
            Item: {
                "Email": { S: email },
                "Topics": { S: eventTopics },
                "SubscriptionDate": { N: date },
                "Status": { N: "1" }
            }
        };

        try {
            const data = await dynamoDBClient.send(new PutItemCommand(command));
            console.log("Success", data);
        } catch (err) {
            console.error("Error", err);
            return { statusCode: 500, body: "Error al insertar el dato" };
        }
    }

    return event;

};

function setVariables(event) {
    eventTopics = convertTopicsToString(event["topics"]);
    date = Date.now().toString();
    email = event["email"];
    regions = process.env.AWS_REGION;
    tableName = process.env.DYNAMODB_TABLE_NAME;
    dynamoDBClient = new DynamoDBClient({ region: regions });

    if (email == "" || eventTopics == "") {
        return "";
    }

    return eventTopics;
}

function convertTopicsToString(eventTopics) {

    let aux = "";

    if (eventTopics.length == 0) {
        return aux;
    }

    for (let topic of eventTopics) {
        if (eventTopics.length == 1) {
            aux += topic;
        } else {
            aux += topic + ",";
        }
    }

    if (eventTopics.length != 1) {
        aux = aux.slice(0, -1);
    }
    return aux;

}

function checkPaymentSubscription() {
    return true;
}

async function checkIfIsInDynamoDB() {
    try {
        command = new GetItemCommand({
            TableName: tableName,
            Key: {
                "Email": { S: email }
            }
        });

        let response = await dynamoDBClient.send(command);

        if (response.Item?.Status.N == 1) {
            return true;
        } else if (response.Item) {
            command = new UpdateItemCommand({
                TableName: tableName,
                Key: {
                    "Email": { S: email }
                },
                UpdateExpression: "set #status = :s",
                ExpressionAttributeNames: {
                    "#status": "Status"
                },
                ExpressionAttributeValues: {
                    ":s": { N: "1" }
                },
                ReturnValues: "UPDATED_NEW"
            });

            await dynamoDBClient.send(command);

            return true;
        } else {
            return false;
        }
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: `Error al recuperar los ítems con Email "${email}" de DynamoDB` }),
        };
    }
}