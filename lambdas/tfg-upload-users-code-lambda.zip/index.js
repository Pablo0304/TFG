const { CodeCommitClient, GetDifferencesCommand, GetFileCommand } = require("@aws-sdk/client-codecommit");
const { S3Client, PutObjectCommand, ListObjectsV2Command, DeleteObjectsCommand } = require("@aws-sdk/client-s3");
const { CloudFrontClient, CreateInvalidationCommand } = require('@aws-sdk/client-cloudfront');


const mime = require('mime-types');
const codecommitClient = new CodeCommitClient({ region: process.env.AWS_REGION });
const repoName = "tfg-users-repo";
const branchName = "master";
const s3Client = new S3Client({ region: process.env.AWS_REGION });
const bucketName = process.env.S3_BUCKET;
const cloudFrontClient = new CloudFrontClient({ region: process.env.AWS_REGION });

exports.handler = async (event, context) => {
    try {
        let blobList = await getBlobList(repoName, branchName);

        await deleteBucketContent();

        await downloadRepository(blobList);

        await cacheInvalidation();

    } catch (error) {
        console.error("Error processing CodeCommit to S3:", error);
        throw error;
    }
};

async function getBlobList(repoName, branch) {
    let blobList = [];
    let nextToken;
    do {
        let response = await codecommitClient.send(new GetDifferencesCommand({
            repositoryName: repoName,
            afterCommitSpecifier: branch,
            nextToken: nextToken,
        }));
        blobList = blobList.concat(response.differences.map(difference => difference.afterBlob));
        nextToken = response.nextToken;
    } while (nextToken);
    return blobList;
}

async function deleteBucketContent() {

    let isTruncated = true;
    let token;

    while (isTruncated) {
        let listParams = {
            Bucket: bucketName,
            ContinuationToken: token,
        };

        let listedObjects = await s3Client.send(new ListObjectsV2Command(listParams));

        if (!listedObjects.Contents) return;

        let deleteParams = {
            Bucket: bucketName,
            Delete: {
                Objects: listedObjects.Contents.map(({ Key }) => ({ Key })),
            },
        };

        await s3Client.send(new DeleteObjectsCommand(deleteParams));

        isTruncated = listedObjects.IsTruncated;
        token = listedObjects.NextContinuationToken;
    }
}

async function downloadRepository(blobList) {
    for (let blob of blobList) {
        let path = blob.path;

        let input = {
            repositoryName: repoName,
            filePath: path
        };
        let command = new GetFileCommand(input);
        let response = await codecommitClient.send(command);
        console.log("File " + response.filePath + " found");

        await uploadToS3(response.fileContent, response.filePath);
    }
}

async function uploadToS3(fileContent, filePath) {
    try {
        let buffer = Buffer.from(fileContent);

        let contentType = mime.lookup(filePath) || 'application/octet-stream';
        let putObjectParams = {
            Bucket: bucketName,
            Key: filePath,
            Body: buffer,
            ContentType: contentType,
        };
        await s3Client.send(new PutObjectCommand(putObjectParams));
        console.log("File " + filePath + " uploaded");
    } catch (error) {
        console.error(`Error uploading ${filePath} to S3:`, error);
        throw error;
    }
}

async function cacheInvalidation() {
    let input = {
        DistributionId: process.env.CLOUDFRONT_DISTRIBUTION_ID,
        InvalidationBatch: {
            Paths: {
                Quantity: 1,
                Items: [
                    "/*",
                ],
            },
            CallerReference: `invalidation-${Date.now()}`,
        },
    };

    try {
        const command = new CreateInvalidationCommand(input);
        const response = await cloudFrontClient.send(command);

        console.log("Invalidación de CloudFront creada:", command);
        console.log("Respuesta:", response);
    } catch (error) {
        console.error("Error al crear la invalidación de CloudFront:", error);
        throw error;
    }
}