const { DynamoDBClient, QueryCommand, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");
const { SNSClient, ListSubscriptionsByTopicCommand, ListTopicsCommand, UnsubscribeCommand } = require("@aws-sdk/client-sns");

let tableName, command, dynamoDBClient, snsClient;

exports.handler = async (event) => {
    tableName = process.env.DYNAMODB_TABLE_NAME;
    dynamoDBClient = new DynamoDBClient({ region: process.env.AWS_REGION });
    snsClient = new SNSClient({ region: process.env.AWS_REGION });

    try {
        command = new QueryCommand({
            TableName: tableName,
            IndexName: "StatusIndex",
            KeyConditionExpression: "#status = :statusVal",
            ExpressionAttributeNames: {
                "#status": "Status",
            },
            ExpressionAttributeValues: {
                ":statusVal": { N: "1" },
            },
        });

        const response = await dynamoDBClient.send(command);

        for (let element of response.Items) {   // For each element with Status enabled
            if (!checkPaymentSubscription(element.Email.S)) {
                await disableStatusValue(element.Email.S);
                await unsubscribeUser(element.Email.S, element.Topics.S);
            }
        };

        return {
            statusCode: 200,
            body: JSON.stringify(response.Items),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error al recuperar los ítems con Status 1 de DynamoDB" }),
        };
    }
};

function checkPaymentSubscription(element) {   // Make a call to the service that controls the payment
    return true;
}


async function disableStatusValue(email) {
    command = new UpdateItemCommand({
        TableName: tableName,
        Key: {
            "Email": { S: email }
        },
        UpdateExpression: "set #status = :s",
        ExpressionAttributeNames: {
            "#status": "Status"
        },
        ExpressionAttributeValues: {
            ":s": { N: "0" }
        },
        ReturnValues: "UPDATED_NEW"
    });
    let disableResponse = await dynamoDBClient.send(command);
    console.log("User disabled: " + JSON.stringify(disableResponse));
}


async function unsubscribeUser(email, topics) {
    try {
        let nextToken;
        let allTopics = [];

        do {
            command = new ListTopicsCommand({ NextToken: nextToken });
            let res = await snsClient.send(command);
            for (let aux of res.Topics) {
                if (aux.TopicArn.includes("tfg-")) {
                    allTopics = allTopics.concat(aux.TopicArn);
                }
            }
            nextToken = res.NextToken;
        } while (nextToken);

        topics = topics.includes(',') ? topics.split(',') : [topics];

        for (let topicArn of allTopics) {   // All topics on the AWS Account with "tfg-" prefix
            if (topics.some(topic => topicArn.includes(topic))) {
                command = new ListSubscriptionsByTopicCommand({ TopicArn: topicArn });   // All subscriptions of the topic
                let subscriptionArn = await snsClient.send(command);

                subscriptionArn = subscriptionArn.Subscriptions.find(sub => sub.Endpoint === email).SubscriptionArn;

                if (subscriptionArn !== undefined && subscriptionArn.startsWith("arn:")) {
                    command = new UnsubscribeCommand({ SubscriptionArn: subscriptionArn });   // Delete subscription
                    let unsubscribeResponse = await snsClient.send(command);
                    console.log("User unsubscribed: " + JSON.stringify(unsubscribeResponse));
                }
            }
        }
    } catch (error) {
        console.error("Error al buscar la suscripción:", error);
        return null;
    }
}