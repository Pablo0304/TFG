const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { SNSClient, ListTopicsCommand } = require("@aws-sdk/client-sns");

let topic, subject, message, date, regions, tableName, dynamoDBClient, snsClient, command;

exports.handler = async (event) => {

    let validParameters = await setVariables(event);
    if (validParameters == false) {
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: `Error al rellenar el formulario`,
                topic: topic,
                subject: subject,
                message: message
            }),
        };
    }

    command = {
        TableName: tableName,
        Item: {
            "Topic": { S: topic },
            "Subject": { S: subject },
            "Message": { S: message },
            "Date": { N: date }
        }
    };

    try {
        const data = await dynamoDBClient.send(new PutItemCommand(command));
        console.log("Success", data);
    } catch (err) {
        console.error("Error", err);
        return { statusCode: 500, body: "Error al insertar el dato" };
    }


    return event;

};

async function setVariables(event) {
    topic = event["topic"];
    subject = event["subject"];
    message = event["message"];
    date = Date.now().toString();
    regions = process.env.AWS_REGION;
    tableName = process.env.DYNAMODB_TABLE_NAME;
    dynamoDBClient = new DynamoDBClient({ region: regions });
    snsClient = new SNSClient({ regions });
    if (subject == "" || message == "") {
        return false;
    }

    let validate = await validateTopicName();
    if (validate == false) {
        return false;
    }

    return true;
}

async function validateTopicName() {
    let nextToken, topicArn, res;
    let allTopics = [];

    do {
        command = new ListTopicsCommand({ NextToken: nextToken });
        res = await snsClient.send(command);

        for (let aux of res.Topics) {
            if (aux.TopicArn.includes("tfg-")) {
                allTopics = allTopics.concat(aux.TopicArn);
            }
        }
        nextToken = res.NextToken;
    } while (nextToken);

    topicArn = allTopics.find(element => element === `arn:aws:sns:us-east-1:905418249319:${topic}`);
    console.log(topicArn);
    if (topicArn) {
        return true;
    } else {
        return false;
    }

}