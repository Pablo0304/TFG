const { SNSClient, PublishCommand, ListTopicsCommand } = require("@aws-sdk/client-sns");

let snsClient, topic, subject, message;

exports.handler = async (event, context) => {

    setVariables(event);

    let command, nextToken, topicArn, res;
    let allTopics = [];

    do {
        command = new ListTopicsCommand({ NextToken: nextToken });
        res = await snsClient.send(command);

        for (let aux of res.Topics) {
            if (aux.TopicArn.includes("tfg-")) {
                allTopics = allTopics.concat(aux.TopicArn);
            }
        }
        nextToken = res.NextToken;
    } while (nextToken);

    topicArn = allTopics.find(element => element === `arn:aws:sns:us-east-1:905418249319:${topic}`);

    try {
        command = {
            TopicArn: topicArn,
            Message: message,
            Subject: subject,
        };
        res = await snsClient.send(new PublishCommand(command));
        console.log(`Mensaje enviado con éxito al topic "${topicArn}", ID:`, res.MessageId);
        return { statusCode: 200, body: JSON.stringify({ MessageId: res.MessageId }) };
    } catch (err) {
        console.error(`Error al enviar mensaje al topic "${topicArn}":`, err);
        return { statusCode: 500, body: JSON.stringify({ Error: err.message }) };
    }
};

function setVariables(event) {
    snsClient = new SNSClient({ region: process.env.AWS_REGION });
    topic = event["topic"];
    subject = event["subject"];
    message = event["message"];
}